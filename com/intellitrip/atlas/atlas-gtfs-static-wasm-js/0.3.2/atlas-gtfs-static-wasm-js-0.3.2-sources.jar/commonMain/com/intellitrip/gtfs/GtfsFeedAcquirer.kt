package com.intellitrip.gtfs

import com.intellitrip.domain.FeedId

/**
 * Default transport for [GtfsFeedAcquirer]: the platform HTTP client.
 *
 * JVM actual: `HttpURLConnection`. wasmJs actual: none — web hosts inject a
 * transport (browser fetch later). A stub throwing here keeps the common
 * signature portable; injected transports behave identically everywhere.
 */
expect fun defaultHttpTransport(): GtfsFeedAcquirer.HttpTransport

/**
 * Explicit, testable static GTFS acquisition. No acquisition runs implicitly
 * at application startup; callers must request a refresh explicitly.
 *
 * Conditional refresh uses `If-Modified-Since` and `If-None-Match` when a
 * prior snapshot exists, honors `304 Not Modified`, validates `200 OK`
 * payloads, and keeps authentication support configurable for providers
 * that need it.
 */
class GtfsFeedAcquirer(
    private val connectTimeoutMillis: Int = 15_000,
    private val readTimeoutMillis: Int = 60_000,
    private val userAgent: String = "IntelliTrip/0.1 (+https://github.com/GhostMan612/Metro-IntelliTrip)",
    private val authHeaderProvider: () -> String? = { null },
    private val transport: HttpTransport = defaultHttpTransport(),
) {

    fun interface HttpTransport {
        fun open(request: HttpRequest): HttpResponse

        /**
         * Async variant (M4c): the default runs [open] on the caller's pool;
         * wasmJs injections override it with the browser fetch bridge.
         * Callers (the refresher) go through [acquireAsync].
         */
        suspend fun openAsync(request: HttpRequest): HttpResponse =
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) { open(request) }
    }

    data class HttpRequest(
        val url: String,
        val userAgent: String,
        val ifModifiedSince: String?,
        val ifNoneMatch: String?,
        val authHeader: String?,
        val connectTimeoutMillis: Int,
        val readTimeoutMillis: Int,
    )

    data class HttpResponse(val status: Int, val body: ByteArray, val headers: Map<String, String>)

    sealed interface AcquisitionResult {
        data class NotModified(
            val etag: String?,
            val lastModified: String?,
        ) : AcquisitionResult

        data class Updated(
            val feedId: FeedId,
            val payload: ByteArray,
            val etag: String?,
            val lastModified: String?,
        ) : AcquisitionResult

        data class Failure(val message: String) : AcquisitionResult
    }

    fun acquire(
        feedId: FeedId,
        url: String,
        currentEtag: String? = null,
        currentLastModified: String? = null,
    ): AcquisitionResult {
        val request = HttpRequest(
            url = url,
            userAgent = userAgent,
            ifModifiedSince = currentLastModified,
            ifNoneMatch = currentEtag,
            authHeader = authHeaderProvider(),
            connectTimeoutMillis = connectTimeoutMillis,
            readTimeoutMillis = readTimeoutMillis,
        )
        val response = try {
            transport.open(request)
        } catch (e: Exception) {
            // The old JVM code caught only IOException; in common code the
            // transport failure surface is `Exception`, so any transport
            // failure becomes a Failure (a transport already maps its own
            // outcomes onto HttpResponse).
            return AcquisitionResult.Failure("Network failure acquiring feed: ${e.message}")
        }

        return summarize(feedId, response)
    }

    /**
     * Async acquisition: identical conditional-refresh semantics over
     * [HttpTransport.openAsync]. The refresher calls this so wasmJs hosts
     * get the browser fetch transport. The sync [acquire] stays for JVM
     * hosts that already invoke it off the main thread.
     */
    suspend fun acquireAsync(
        feedId: FeedId,
        url: String,
        currentEtag: String? = null,
        currentLastModified: String? = null,
    ): AcquisitionResult {
        val request = HttpRequest(
            url = url,
            userAgent = userAgent,
            ifModifiedSince = currentLastModified,
            ifNoneMatch = currentEtag,
            authHeader = authHeaderProvider(),
            connectTimeoutMillis = connectTimeoutMillis,
            readTimeoutMillis = readTimeoutMillis,
        )
        val response = try {
            transport.openAsync(request)
        } catch (e: Exception) {
            return AcquisitionResult.Failure("Network failure acquiring feed: ${e.message}")
        }
        return summarize(feedId, response)
    }

    private fun summarize(feedId: FeedId, response: HttpResponse): AcquisitionResult {
        // HTTP header names are case-insensitive. The JVM transport preserves
        // the publisher's casing (`Etag`, `ETag`, ...), so normalize once
        // instead of hoping for one spelling.
        val headers = response.headers.entries.associate { (key, value) -> key.lowercase() to value }
        return when (response.status) {
            304 -> AcquisitionResult.NotModified(headers["etag"], headers["last-modified"])
            401, 403 -> AcquisitionResult.Failure("Authentication required for feed $feedId")
            429 -> AcquisitionResult.Failure("Rate limited while acquiring feed $feedId")
            in 200..299 -> {
                if (response.body.isEmpty()) {
                    AcquisitionResult.Failure("Empty GTFS payload for feed $feedId")
                } else if (!GtfsArchive.isZip(response.body)) {
                    AcquisitionResult.Failure("GTFS payload for feed $feedId is not a ZIP archive")
                } else {
                    AcquisitionResult.Updated(
                        feedId = feedId,
                        payload = response.body,
                        etag = headers["etag"],
                        lastModified = headers["last-modified"],
                    )
                }
            }
            else -> AcquisitionResult.Failure("Unexpected HTTP ${response.status} for feed $feedId")
        }
    }

    companion object {
        fun sha256(bytes: ByteArray): String = Sha256.hex(bytes)
    }
}
